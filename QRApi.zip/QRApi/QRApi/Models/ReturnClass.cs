﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QRApi.Models
{
    public class ReturnClass
    {
        public string AppData { get; set; }
        public string SuccessData { get; set; }
        public string ErrorData { get; set; }
    }
}