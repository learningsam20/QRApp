﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace QRApi.Models
{
    public class QRMain
    {
        public string ValidateUser(string UserEmail, string UserPass)
        {
            string retStr = "";
            ReturnClass retClass = new ReturnClass();

            try
            {
                QRDBEntities qDB = new Models.QRDBEntities();
                var user = (from u in qDB.User_Details
                            where u.User_Email == UserEmail
                            && u.User_Password == UserPass
                            && u.User_Act_Ind == true
                            select new
                            {
                                userName = u.User_Name,
                                userEmail = u.User_Email,
                                userID = u.User_ID,
                                userDOB = u.User_DOB,
                                userOffers="",
                                userQRC=""
                            }
                         ).FirstOrDefault();
                if (user == null)
                {
                    retClass.AppData = "";
                    retClass.ErrorData = "Error in authenticating user..please check user email/password!";
                }
                else
                {
                    var userQRC = (from uo in qDB.User_Offers
                                   join od in qDB.Offer_Details
                                   on uo.Offer_ID equals od.Offer_ID
                                   where
                                   uo.User_ID == user.userID
                                  select 1
                                   );
                    retClass.AppData = JsonConvert.SerializeObject(user);
                    retClass.ErrorData = "";
                    retClass.SuccessData = "User details found!";
                }
            }
            catch (Exception ex)
            {
                retClass.AppData = "";
                retClass.SuccessData = "";
                retClass.ErrorData = "Error in login: " + ex.Message;
            }
            return retStr = JsonConvert.SerializeObject(retClass);
        }
        public string AddUser(string UserEmail, string UserPass,string UserName,string UserDOB)
        {
            string retStr = "";
            ReturnClass retClass = new ReturnClass();

            try
            {
                QRDBEntities qDB = new Models.QRDBEntities();
                var user = (from u in qDB.User_Details
                            where u.User_Email == UserEmail
                            && u.User_Password == UserPass
                            && u.User_Act_Ind == true
                            select new
                            {
                                userName = u.User_Name,
                                userEmail = u.User_Email,
                                userID = u.User_ID,
                                userDOB = u.User_DOB
                            }
                         ).FirstOrDefault();
                if (user == null)
                {
                    retClass.AppData = "";
                    retClass.ErrorData = "Error in authenticating user..please check user email/password!";
                }
                else
                {
                    retClass.AppData = JsonConvert.SerializeObject(user);
                    retClass.ErrorData = "";
                    retClass.SuccessData = "User details found!";
                }
            }
            catch (Exception ex)
            {
                retClass.AppData = "";
                retClass.SuccessData = "";
                retClass.ErrorData = "Error in login: " + ex.Message;
            }
            return retStr = JsonConvert.SerializeObject(retClass);
        }

    }
}